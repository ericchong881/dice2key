# Dice to Key

This is a simple script for converting dice rolls into a Bitcoin private key. The output is a 32-byte hexadecimal number suitable for passing into [bitcoin-bash-tools](https://github.com/grondilu/bitcoin-bash-tools/) or another public-address calculator.

This script is a companion to an article I wrote on [creating bitcoin private keys with dice](http://www.swansontec.com/bitcoin-dice.html).
